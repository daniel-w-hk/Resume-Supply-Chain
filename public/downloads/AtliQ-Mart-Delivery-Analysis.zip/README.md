# AtliQ Mart Delivery Performance Analysis

Independent practice project by Mingkang Wang using Codebasics AtliQ Mart sample data.
个人实操项目：使用 Codebasics AtliQ Mart 样例数据分析交付表现。

## Contents / 文件说明

- Reports/Report-EN.pdf: final English analysis report (8 pages).
- Reports/Report-ZH-CN.pdf: final Simplified Chinese analysis report (8 pages).
- PowerBI/AtliQ-Mart-Delivery-Performance.pbix: the existing six-page practice report.

Start with either PDF. The reports explain the SQLite checks, delivery measures,
customer/city/product/time comparisons, findings and proposed follow-up actions.
请先阅读 PDF：包含 SQLite 核对、交付指标、客户/城市/产品/时间分析及跟进建议。

The PBIX retains the supplied practice interface, including its original page names
and filter state. Use the PDF for the written conclusions and metric definitions.
PBIX 保留练习时的原有页面名称和筛选状态；分析结论及指标口径以 PDF 为准。
Power BI Desktop is required to explore the PBIX; report visuals use imported data.
Refreshing external data sources may require updating local source paths.

## Attribution / 来源

Dataset: Codebasics AtliQ Mart, March-August 2022.
Reference project: https://github.com/biswajit-sasmal/atliq-mart-supply-chain-analysis
The sample data and reference project are not claimed as original work.
原始数据及参考项目不属于个人原创；本包展示个人练习报表与分析成果。
Recommendations are analytical proposals, not implemented business improvements.
Package excludes course repositories, duplicated reports, raw screenshot folders
and compilation files. No internship, client engagement or certification is implied.
