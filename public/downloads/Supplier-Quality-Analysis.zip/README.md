# Supplier Quality and Downtime Analysis

Independent practice project by Mingkang Wang using Microsoft's Supplier Quality sample.
个人实操项目：基于 Microsoft Supplier Quality 样本重新制作并分析报表。

## Contents / 文件说明

- Reports/Report-EN.pdf: final English analysis report (5 pages).
- Reports/Report-ZH-CN.pdf: final Simplified Chinese analysis report (5 pages).
- PowerBI/Supplier-Quality-and-Downtime.pbix: the supplied rebuilt four-page report.
- DAX/measures.dax: measures extracted from that report, with home-table comments.
- Results/: supplier, material, plant and selected combination summaries.

Start with either PDF, then explore the PBIX in Power BI Desktop if needed.
The four pages are Quality Overview, Supplier Analysis, Material Analysis and
Plant Analysis. The analysis distinguishes defect quantity from downtime impact
and narrows follow-up priorities to supplier/material/plant combinations.
请先阅读 PDF，需要时再用 Power BI Desktop 打开四页交互报表。分析区分缺陷数量与
停机影响，并将跟进重点定位到供应商、物料及工厂组合。
The Results files are aggregated analysis outputs, not the original source dataset.
Results 文件为分析汇总结果，不是原始数据集。

## Attribution / 来源

Source: Microsoft / obviEnce Supplier Quality Analysis sample, 2013-2014.
https://learn.microsoft.com/en-us/power-bi/create-reports/sample-supplier-quality
The original sample data and sample design are not claimed as original work.
原始样本数据及样例设计不属于个人原创；本包展示个人重制报表、度量值与分析成果。
Recommendations are analytical proposals, not implemented business improvements.
Package excludes course repositories, duplicate reports, raw screenshot folders
and compilation files. No internship, client engagement or certification is implied.
